/*
 * Copyright 2009-2010 Freescale Semiconductor, Inc.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * Version 2 as published by the Free Software Foundation.
 */

#include <common.h>
#include <asm/fsl_ddr_sdram.h>

fixed_ddr_parm_t fixed_ddr_parm_0[] = {
	{0, 0, NULL}
};

fixed_ddr_parm_t fixed_ddr_parm_1[] = {
	{0, 0, NULL}
};
