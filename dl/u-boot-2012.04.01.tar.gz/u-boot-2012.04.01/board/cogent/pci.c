/* pci not implemented yet */

int cma_pci_not_implemented = 1;
