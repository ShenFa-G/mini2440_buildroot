#define GPIO_PIN_1 GPIO_PG5
#define GPIO_PIN_2 GPIO_PG6
#define GPIO_PIN_3 GPIO_PG7
#include "../cm-bf537e/gpio_cfi_flash.c"
